<?php
session_start();
$names=$_POST['party'];
$voted='voted';
$email=$_SESSION['email'];
$con= new mysqli('localhost','root','','registration');
$p="update registration set Party_num='$names', voted='$voted' where email='$email'";
$part=mysqli_query($con,$p);
// header("location:homedis.html");
echo "name:".$names;

?>