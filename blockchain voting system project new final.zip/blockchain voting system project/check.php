<?php
session_start();?>
<?php
$email=$_POST['email'];
$pass=$_POST['password'];


$con= new mysqli('localhost','root','','registration');
$a="select name from registration where email='$email'";
$n="select voted from registration where email='$email'";
$q="select * from registration where email='$email' && password='$pass'";
$p="select * from registration where password='$pass'";
$ad=mysqli_query($con,$a);
$rese=mysqli_query($con,$q);
$nume=mysqli_num_rows($rese);
$resn=mysqli_query($con,$n);
$numn=mysqli_num_rows($resn);
$row=mysqli_fetch_array($ad);
$nulls=mysqli_fetch_array($resn);
$nulls1=$nulls[0];

// $resp=mysqli_query($con,$p);
// $nump=mysqli_num_rows($resp);
if($nume==1){
    $_SESSION['email']=$email;
    $_SESSION['username']=$row[0];
   if ($nulls1=="voted") {
    header("location:homedis.html");

}
   else{
     header("location:test.php");
    // echo ""
    
}
}
else{
    echo'<script>alert("wrong info")</script>';
    header("location:login.html");
}
?>