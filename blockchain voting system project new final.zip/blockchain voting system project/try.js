var con = document.getElementById("con");
var tri=" "
function fun(){
    con.innerHTML="hello";
    tri=50;
}
console.log(tri);