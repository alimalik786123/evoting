


function check(){
    var txt=document.getElementById("box").value;
    if(txt==="CONFIRM"){
        window.location.replace("vote.php");
    }
    else{
        alert("enter CONFIRM correctly");
    }
}
function red(){
    window.location.replace("voting_page.php");
}
function logout(){
    window.location.replace("login.html");
}
function onload(){
    var temp=document.getElementById("check").value;
    $.post("check.php",{temp: temp},function(data){
        if(data==0){
            alert("welcome")
        }
        else{
            $("vote11").disable();
        }
    })
}
function validate(){
    var pass1=document.getElementsByName("")
    var pass2
    var adhar
    var phone
}