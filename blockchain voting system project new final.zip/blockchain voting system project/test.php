<?php  
 session_start();
 if(!isset($_SESSION['email'])){
    header('location:login.php');
 }
 
?>
<!DOCTYPE html>
 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    
   
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://kit.fontawesome.com/db37ad52d4.js">
    <title>Vote now!</title>
    
   
</head>
<body>
    <nav class="sidebar">
        <header>
           
                

                <div class="text logo-text mx-5 my-5">
                <h1 CLASS="FIX">FRCRCE</h1><!-- <img src="https://res.cloudinary.com/crunchbase-production/image/upload/c_lpad,h_256,w_256,f_auto,q_auto:eco,dpr_1/hlm1pwk3maltiktxm35b" alt="" class="log">                    -->
                <span class="name"></span>
                    <span class="profession"></span>
                </div>
            </div>

            
        </header>

        <div class="menu-bar">
            <div class="menu mx-1 my-2">

    

                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="#">
                            
                            <pre>.       .</pre> <span class="text nav-text">Profile</span>
                        </a>
                    </li>
                    

                    <li class="nav-link">
                        <a href="Adminlog.html">
                            <pre>.       .</pre> <span class="text nav-text">Result</span>
                        </a>
                    </li>
                    

                    <li class="nav-link">
                        <a href="login.html">
                            <i>  </i>
                            <pre>.       .</pre> <span class="text nav-text">Help desk</span>
                        </a>
                    </li>


                    <li class="nav-link">
                        <a href="test.html">
                            <pre>.       .</pre> <span class="text nav-text">About us</span>
                        </a>
                    </li>
                    <li class="nav-link" >
                        <a class="logout" href="login.html" onclick="logout()" style="text-align: center;">
                           <pre>.       .</pre> <span class="text nav-text" style="text-align: center;">Log out</span>
                        </a>
                    </li>


                </ul>
            </div><br>
            <br>

            <div class="bottom-content mx-3">
                <!-- <li class="">
                    <a href="login.html">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text mx-4" id="lgout">Logout</span>
                    </a> -->
                </li>

                
                
            </div>
        </div>

    </nav>

    <section class="home">
       
        <div class="texthead"><p class="college">WELCOME <?php $_SESSION['username']?></p>
            <div class="searchbox">
                <form action="#" method="get">
                    <button type="submit"><i class="bx bx-search icon"></i></button>
                    <input type="text" name="search" maxlength="60" placeholder="Search..." required>
                    <img src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_640.png" class="pro" alt="">
                   <img src="https://cdn-icons-png.flaticon.com/512/25/25682.png" alt="" class="logo">
                   <img src="https://cdn4.iconfinder.com/data/icons/ionicons/512/icon-ios7-bell-512.png" alt="" class="bell">
                </form>
            </div>
           </div>
        <div class="col">
        <div class="row mx-3 my-3">
            <div class="col-lg-6 len">
                <div class="card bg-primary text-white mb-4 len" style="background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAACIlBMVEX///9Gv733Rkq/P78/f79vb29/vz9/P7/+tFy/Pz+Ws9X79fGFps3Pflr57ujXlHn4+fzw2M/KbTz15d3GW8bDTsNtl8Wiutjn7vbdqpWtxN8yebzg6fPX4e67zeN5MrygoaC3yuHw9+y+3Kf3P0zF1uhzuiZ5vTP+xYbIZDLSiGjGq+B1Krvs5PUmc7m9NTbYpqLYlZEiVYhTgiJWJ4TGW1QAAACAKCWCI4Lu7u7gueW8MbzBwsHc3dyOj47R0tGvsK9/gX/3OD0vLy+XmJdhY2FVVlSsrau04LXI6Mnk9OVZwlt8zX7V7tac2J1HTExKv00ZHhg3Ojb3LDL7tbX+rkt3zs4AsACp3Kpqx2yM0o3HYCXCVgC7MwCtl5DRx8GFfnLboWKpYgAjJSjcrn3rza7GeABeQCV2SxbYjS+jrbZfOAATFxeMVQjjuI9fam+wYABFVVyqoo7VjjuHc2LAjlVjWVHDuKyiailBJgA+R0uzdCKFYDeok4EzKSCzkHGQeGC/oouhgnzXk0aEj5pNLAR1UCgfEQBAPDRQPiyYaDIxuTXIqY3pxbaeeVTr0rwAGic4JhQpEACCaWTjoFQADRm4lY7AhkeWZWGGO4iBl3CGdZgJEgj+5Mb7naH8xsb5g4T90qH5bG6NwW+MuX2Fu2Gjw8RWmWVZnn675ubY1blvz9Kwzrtenk/WtsRuo5j6Kh6mlbTIfo77d3nIUmTQlaaMZpg/AAAUN0lEQVR4nO2djX/URnrHx75Tm9q+jTbu2Y7P+IR9tDT3Eq4vbtVqNJJX2sUGI1Z2XCApBhaclxIICdg+m2BK0lx4C+SaC3etAeOXu3AkKT0u/19nRi8rraTdkbS7xmF/8LFnn5VG0nefeeZ1xyDHteRXDnCgJb+4FpOAWkyCajEJqsUkqBaToFpMgmoxCarFJKgWk6BaTIJqMQmqxSSoFpOgKBO41XcRW709PY3LnDJRRYYj/7lCjbsnBiUispfxOMpEYDny+//i03eS3FXdlITJ2L+Osx3IzuQvv+PT9xPcVf2UhMnhsUNsBz5DTPaBw2wHPjtMsJfsYzvy2WFyeAgcYQsolInMUhlvdyb7qKuw6JnxE8qDLaA8M0z2D+EfB5kOfWaY0PjKFlCeFSYTNJSMMTVlrRjL0rZPyuTFV18I6rUwI5P+jWYamwktOowBhTLRWI5MzCQTZuy2fh8tmzzJmSr14N/Qnz39vazXt2RHEqYWSuPLjvP4fmPW+p0rmzxJTYrOzmbCenVbEwes37a7VNfWMskUOx1LplT2p2OF6OySMdlvB1emgLKVTPjjJ0onTloGT/LU7OtvvBlW4KiSMXHKzNB+hoObxgS+1al0vtWp9VlGwuTkv589ffbtU+T1GZo8Q5Ld75wz8x+/GZVdIiZO0WELKFH1zo7+nV7182mZdMrvFnYdm+d4y0iYzJ7lNF19j7x+s5w8eX5Rk89dCPMuokRMyu0SloAS5Sf9P/uBVz/rS8tkRp6X4Rya32EZKZOSrhk5CmI2p2v53BJJnrya09TSQjYiu0RMyt6xlyGgRDL5wXe9Ss9EhEDshKJdyxIm8BdGycjlzgOSXCwZpdzr5K1jlxaN0uIvoqrjJEzGj7hJloDSNCYVxiw4akpLF9+/eE0+Lc7naHJBW4GZS8LywuXLS0dLEY2mJEy8TXpfl2cstK2/dUywmb+xPI8jTTZjJXGoIUkws/wf2EsiCk8SJl4OnoBy6OCBUK/ZOiYJlYCJp+iUA8r4/n1jdKApqKh6p45MspmAOp+/GTQyqfPV+EwOTHheWAFlbJ/VihsPc5Qm+Mn3XgrqhTAjk16jmfbs2MXOZF/lq70H3fZKmKM0gUloH9AuO1fKpishh4XILjuD/azX9xcdHFAO7PPUxxNHQEBbHE/C+4DVFD+e+IoOLjx+zwgZettaJrcuuW9mc2xhNz6T6s35EEdJE2OH/Iq4aJU+4AdvlxaOW4bPFtxkdbEzsZtntVppQUdJ4SdDf+XXcPg1nbb9h52CqAHF0wc8/p9nT597g3b8aHfwo5MMT8rO5NBhGkkPTVQ/bOxApSUVkz/z6q+rMwFH31XQsXnVw2T2rCrYHT/cHRQ4K1lD7EwOggPkcWv2hAOO0jQm85ykwrmj6oBlpExu52Uj9wF5/WYprxmlJYYnZWZCqpsjexk6OHsrZ8Ka5yd+I2Yi/TKP+4DmVdykR7/M54zSx1cZxsqZmdBOzv6xvWM1j6x0lK1jckVHdy6+f+2CUoRH8+jOtfcv3lGKMzUfgJmJVWYOX699ZOX4QYp6J8jkpz/2i44fRTEhI7HzNwiEbpKcuTFPkjUfgJWJMzfMMkVc4Sh19ZMf/+SHXv3kpySnLeoDhvbuInTI7yj1ZfLDP/fKZnIzG9TzYUYWdbP2ARnXmljyO8oWMXnpRev3i2WTJ3nzZljSks2k1pwXQ2iNVBOYVOsDzpVNnmQBuUlYeW+MZYdtBUG4msAk1TygpFacycaEaR4nSna9s+cffNrTHCadJy+dsScCO8+Uzji136nLnzjn3Fp+/Zb/zGpMyqOrB2o06KvK9pOfv/wXHr3cHCaZ2bnS5VlKQpw9j5NWKTt+zZybpTNh4OSS8XFF17AKk7HrbtclTdFpHpMZNaOJ8gznadt/kMPN2PO043f8U5yco09/6+1F01ycJf7TfWLRyJWWfJ4SzWRiH9hnV8ATgX7dU8kEFEgfENgNVbsPKBdUuw/IqQWVs+a8jhmSkL9ADjhz2VAKxvu+7nIkk4mD5eHV/YwrpreYybw6I8M5XvIwWbptyrncHeAkSxTPmU9Pq/rtBXLWqY9+zXGlj26wMBmnxcVuqcVqnIQzkcWtiCfCyFzJWLxqQuxDI3O4HM2VcBLmruYXS3MjBRxkjE/10mL+V75v00QwsZCAIUqDdRF5NSZbEmOvqOKdheWFZZSb+VwVLywsX7uAzPnsHLx5YvmTJcT9V/YqmjnxyfKJeeGSJ4twJkNOV+8IqXAY15A/fUyIZubJtHCnlZxxkuL8DG8nO2dmRMdchclQufeL/WXo6WdSrR0bX2FMhjxV74ExcChFu56oCUxeej6oF8KMTHothMl1bx/4YMoI2xQm2e6gnr9p/b5ZNnmTYadYyoT0AQ/6hgX27g+ZxorPZGvqHaKPyyajnBRirXu8XjFScj1V4wRsdYwFpbLJ0weU4zA5WIkgxmBSuLaUSfazS8ftd7s/KznJzpMXr52KvOFKJgEk6dU8Jrz9j4oyufWOfpo7Qd/OkuQ7FBQ/e97ML0ROf1UyqT+SJvYBz82rUJ9XPWv83ls08rnztOP3gWnkTY5O9Zy6WNKNxfeiFsgmWx/7dDIB0rvKrmMzunfdo477gDpdCTt7FvcBz1l9QC6vaIvXboXdbROZNKPemf9QLHRqUsGzPnbhdk49XbpAXl+7XeJKpWskeeNT7Ce333gm/MQnzEQ0jYsmZ1z8tYY7e8bFxbM4KePPp/TR3NnFT35lRMwJfquZfA7BzaU7CzNA2HMUkeTSPCh8nlVA5s7SwjJAEeuWvtVMqDzO4Onn8VVuOIQJH5GOflH9qG9BH7Cvy/Oio8/zwjsHxHuP6h2IOIpmbO1rofzmH326onz4t369pfz2n3z6rVL4O7/+W/mfv/dLKGA/ePGF7wX1apiRSc5333hXmImbBh0D5Tfw05Zf8N6jendEHeUywUb/hyEGAlyIBfIVEivXyPM8HR6pr2jO/V2x1cF01KDLpCWvWkyCajEJKowJJNGDBhCEPCFCRKLvoEQSeYSzgTQ7OwGCrTN+S3d4CmGiSIDLAT6Pk0WkI/wYFBAypLyE758n/3mQY/medlB50UCGSDbSkAWpKOLcgaiTPMk1eNH+CZl2eGqUQpgY+M5VSDeeMkUVCZohjmjYTO5b1SVO1lTdEE25mOBykiLq+J9obTBiQlXSzQKmpAqCuoKKsiDn4YhswqIqs2RX4CHHiZAMQXGqswJB81ai2Ag9I1SI4zwuqISTD2Wi5DkVFHBWOUmVEGdCE5tNIHGqDDEWVeWRYAA9wWeJzzckDgHshJquSjgzHjtFAQFDBwVk4nvGgICsyEBnyA2jLZIf+FPEbi1IkiwKGr4vDRQ0IAkCoKN3ECpCAUAZ4RPwg+R5TUGaJAqyKKsCIxOTlIsVIOA8TF4QTOztZFxQ0kVBVWFBwz8LKr7/JEwEJOq8qhAmpPyIqqzoEvY9jFvK48vkoS4VoYlUWnRrqSAh6k4kq6K8IupIKEiqaiIFU1UllTwBvvECzlXMQezXioIjAzTwbYxAQzQ0JfQb7yFMOBEfiEQyZlwQcAQRkOV9EL/AYVFBSMW8JCBV65ZECKo0T0kgV8CfLsLZYRdG+F4VHVkXMxVRJPnXlobEPCkeOEfMUNI4Hpd5HTPRZAWpomAzUfJARTlJ4QFSsavgezClHJSBqUGFkYko0Luv8v14pn0wIk6lPysXH2FhT7FTLKXGPqcAZE5X8KcI+KJmYG+ARh7pYhHmOQUzwQ9c1GTKRORk8iGrnMpBXNjkEbTCKTIsMDLZRsqXf1V2Txy59or3UXQQ395MIH1QmMRtRRT51vZm0hi1mATVYhJUi0lQLEw6HHWFpKq9WTbF+DZwbXV237374O69qan72c7aR8cXExMnMdgXMA24Jne8s88FsNPNIuaOUNHK3N393CtEu0exJifbV6cit9RJqlhMdg4ETAOuyWUyMOik3O9F8/VhknmAeTxnafeP2i2NTrbfqy+WbcTk7m6Hh48JxfIk8TxAiLYNk7vPeYn4mWBNrtX+ihirtgmTzG4/kQATTGU15TVc1Y9Jx8Twxsb6+vrGxsbw8ARdFlI3Jg8qiYQwaR8dvZ/uKo7qw2RoeH39i+EJa9XUwODQ+NjwxvrGRJ2YdAacJJRJ3VylDkyGNjaHJ7xlx66Lh4Y3h+21ZamY9IUhCWXSPrqW4jqumJg4E3397pSiaxrYu7kxbs09OqYdg+7x4xubY2TmsS8Fk4dt0yFIwpm0j7bXoRXHwqRrl62Ofidlm373+40vHVOPk+jv8B41tvnFF7sGkzN52NbW9iUzE6z0bZV4Zcffjh1aHx4Kq3cq2rHjw8PJ27EECYbCEmMdJb2Uq+TxZGh9Y6jhdXFfm6U/BKBEM0kNJTGTsU0aPxvMpM1RoDaOZjK6mvBijpIy2bR3bGgsk2mXyaPd7H4yOZXsao6SMRn/ylnAXYVJ5p7bL07I5GFbWZWVTxUm7ZPp4mwiJhObLG37e/dTMuHb2qKhVGPSnq6ZkoTJxDpTf6c9bdmZ9jGpqHyqMklXehKMKQ1tMo0pTU2lHFPqa6vQH6LGCkLibILruWJh0uOMIPbQwcSv8E/X1OWOL37XNVlvtnd5jkrCZLqSSdupV5iZpHGU+H6yPg5Y/OT+asqxx4CbYO1mZZKqkRI7nowN+0yR8YR0PFLFk6Cb+GrkGkzSjBvEZrLpN0Ux6SahPxWTECTeyqeWn6SoeuIyWR/3m6KY0AHSNEwehjIpdwdrMUnRRonZB5zYqDBFMMnQ8pyGSVjR8VY+tZikiLIxmWxWmiKYrNLinIZJBBK38qnFpP1J7Es6isfky+FKUwSTSZpKwSSs1nEqn1eYmCRvosSri78KmMKZWG6ShklEOCGyKp+aTCYTT/nEYjI2FjCFjynZn1GK/k5UOCGaZvOTxAGFaexx0NZX/U6qx0n09gZNHWtfWyn3xJ2xmVRBYlU+tZncSwQExPOTsf9lm0MfdBqRKfykKhNS+dRkkjzIxmGyOcg2D/iyU5KTxxO+OhNc+dRmkrh5H4PJxDAbk+yqk2ock7YHTweTTcb54skdTio5kypVsaVHD0ZrMkk61cPOBFc6TEyefOPOZTSQSdv06uTW+8km27qC+2t9dRijrs2krU1aq+EqDfeT8WEmJpnHdRm3rxlPqPa0V6US85qumJmQCS6G9WyPO+uyno2NSdv0vdFoKolHC5jGHvv7+wd/j390dfTb6nESHT7Tzsf/h01djslN9Na5fVLW755EhpXVJDyIWNcV7J0IX1ewwzV18bz4OEtMO911BU4i/roCVibRYaXx7Vg6SLAzpOx44knmMV1TVjmHDurd36nQoz2hBSj56GMd17N1P7YCfV3mRqv0i4OavhdSgCYTL/qrH5M/OnVfXZiwVMYehYSVJo2fVGOy9ifXVJc59HhMcFiprJebNc4WyeT+42yd1xXECCiWKsJK08ZjI5hkSb1XZyaxAoolX1iZTL6wLS2THQMgu7ZGrl/v9SfxmeCwsjaZvuik/17G1+1PrJmUyPVsoH7zgLX1tR1WGj0P2DVo/cHewa5eJ2UNNO5660+TqzsHB22T/V5vh3u8k4j718uJYtY8jh793AorCVg4Sr7uMTO1Nrp2n2HdI0i4/iSZo1ijCM1bV2Ax6cxkp/6IedAvEzVwPVtCR2kjYaXh609sJpnsN1NT9/CHsHZv6hsnqjdyjV9SR8FKtX8KM5Ns+9oqZnK/u2wiaiQTxgGDED1KcjlXadZREzV0LWiCNoqlBLtLePR0f6cpYel5mOxqjp5uJokabm3TCS/mKHWbrXF1MT0xAZJ0wQQwttn6bPXvclKuaVeIqd9J9TqJgcTfy0hQISe9lCsmJjtsdQw6Kdc06JgGegYcU697vJPYkfz7OwNxkaSLr0RPedkBsaEkv5CrpzzG0pNjEEkbXqm2AZMYVXLKStjWtmDC2nirD5JtwgTwDK5Sl3JDtE2Y1HaV6b7aeTBq2zDBVB41hcg22xOGD3eWR3WKI44SfH+HpoLf3ymbeoKm/poXYVTfw4rIMv0wfSOtQttyj6m+h7bqWWLK2pZMGqwWk6DC9gUVJQnZWylKnr+uDCJ2SJQCdmszfLINo+ctybsFZ9wtGhG+J4mnW2TjfNyzyX26OdVtu+YQJnmyJ7JMtkcGpiRw1obdIiiKiCdJcm1INvCwdtjmc0jVeEB2/BeJleyUqwgkH7KxrwRESM8GpiKZJCvyPgSyFOsJJEHQEN2dGBShokN7c++cJMsC2UAZkls06wUlyEQSyA6uKyBPt6AFvKRzSl7OiUXEaXoe5QEHTUFXJCRwAr7JQgEfo0JFKgp5Xkd5TZM4g+49q2EmOZRTBU2HdGtSERaRrqyII5oq6DrLprmO8kAQMBOyIawJYF7A2Rj0TgGPc0KcUoQjkhm902daJvjClIkMKRPIiUDXgSoagNOgJOFkQQN5ATORDA0zUfAxMnZtA0iaLuky3a0a8LJAt/lFgqgSOJIM5CL+oaorogwMAZEHYpYJBA2XGZwvMGWZF6ScrIvWbsWYVUFQc4gDLLs1J2SiSMAQZZls3guKUkFXZEHDziGaEDNRFF0qIhOZkqoKHCqSDX4RdmBBxyUDjEhQx3eocQLZwlZTIO8ywcUQ4VKGXX9EzCFdi82kACGQFOtP5mnIhGRL3BUkqJhuYQWOYCZGvTbFDzIRdaAoyP4bhmS/ZvIBAcRDhCCODLyCY53CYyvkFRpQyMGSRDex5gG03iLnYoBQEiGPrDBIYiR2PQlBjkTJwB8cqSYNiYqi0F3BSZGDonVpcnskJ1FBIo62jSs7QKCPgOp1hYCs/a7jSU56YhK12idBtZgE1WISVItJUC0mQbWYBNViElSLSVAcyHEt+ZX7f7sZ/OVc1+P8AAAAAElFTkSuQmCC');opacity: 0.85;">
                    <div class="card-body">Previous result</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="events.html" id="card" >View Details</a>
                        <div class="small text-white"> </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 len">
                <div class="card bg-warning text-white mb-4 len" style="background-image: url('https://www.vqcomms.com/wp-content/uploads/growth-graph.png'); opacity:0.9;">
                   
                    <div class="card-body">Result</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="events.html" id="card" >View Details</a>
                        <div class="small text-white"> </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 but">
                <button class=" btn-5 but1" id="vote11" onclick="red()">vote</button>
                </div>
                <div class="col-lg-6 but2">
                <button class="btn-5 but2">prev</button>
            </div>
            </div>
            </div>
            
    </section>
    <script src="voting_page.js"></script>
    
    
</body>
</html>