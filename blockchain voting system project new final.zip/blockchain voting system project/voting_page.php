  <?php  
 session_start();
 if(!isset($_SESSION['email'])){
    header('location:login.php');
 }
 
?>
<!DOCTYPE html>
 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    
   
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://kit.fontawesome.com/db37ad52d4.js">
    <title>voting_page</title>
    
   
</head>
<body>
    <nav class="sidebar">
        <header>
           
                

                <div class="text logo-text mx-5 my-5">
                    <h1 class="FIX">FRCRCE</h1>
                <!-- <img src="https://res.cloudinary.com/crunchbase-production/image/upload/c_lpad,h_256,w_256,f_auto,q_auto:eco,dpr_1/hlm1pwk3maltiktxm35b" alt="" class="log" style="position: fixed;">                    -->
                <span class="name"></span>
                    <span class="profession"></span>
                </div>
            </div>

            
        </header>

        <div class="menu-bar">
            <div class="menu mx-1 my-2">

    

                <ul scroll="no" class="menu-links">
                    <li class="nav-link">
                        <a href="test.html">
                            
                            <pre>.       .</pre> <span class="text nav-text">HOME</span>
                        </a>
                    </li>
                    

                    <li class="nav-link">
                        <a href="#">
                            <pre>.     .</pre> <span class="text nav-text">Help desk</span>
                        </a>
                    </li>
                    

                    <li class="nav-link">
                        <a href="index.html">
                            <i>  </i>
                            <pre>.       .</pre> <span class="text nav-text">About Us</span>
                        </a>
                    </li>


                    <li class="nav-link">
                        <a href="logout.php">
                            <pre>.       .</pre> <span class="text nav-text">Logout</span>
                        </a>
                    </li>
                   


                </ul>
            </div><br>
            <br>

            <div class="bottom-content mx-3">
                <!-- <li class="">
                    <a href="#">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text mx-4" id="lgout">Logout</span>
                    </a>
                </li> -->

                
                
            </div>
        </div>

    </nav>

    <!-- <section class="home col"> -->
        <div class="home col">
       <form>
        <div class="texthead row-lg-2" ><p class="college">WELCOME<?php echo"name".$_SESSION['username']?></p>
            <div class="searchbox">
                <form action="#" method="get">
                    <button type="submit"><i class="bx bx-search icon"></i></button>
                    <input type="text" name="search" maxlength="60" placeholder="Search..." required>
                    <img src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_640.png" class="pro" alt="">
                   <img src="https://cdn-icons-png.flaticon.com/512/25/25682.png" alt="" class="logo">
                   <img src="https://cdn4.iconfinder.com/data/icons/ionicons/512/icon-ios7-bell-512.png" alt="" class="bell">
                </form>
            </div>
           </div>
        <div class="row det">
        <div class="row mx-3 my-3">
            <div class="col-xl-4 col-md-6">
                <div class="card bg-primary text-white mb-4" style="background-image: url('https://static.toiimg.com/photo/msid-94674893/94674893.jpg');opacity: 0.85;">
                    <div class="card-body">Aam aadmi party</div>
                    <div class="card-footer d-flex align-items-center justify-content-between footer1">
                        <div class="small text-white"> <button class="rem" id="aap" data-toggle="modal" data-target="#exampleModalCenter" onclick="fun(this.id)" >Vote</button></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="card bg-warning text-white mb-4" style="background-image: url('https://images.news18.com/static_news18/pix/ibnhome/news18/assam-assembly-election-2021/party-images/bjp-symbol-og.jpg?v=44'); opacity:0.9;">
                   
                    <div class="card-body row"><div class="col">Bhartiya janta party</div>
                    <div class="col-lg-4 "><img src="https://th-i.thgim.com/public/news/national/kerala/ml9cvu/article33196294.ece/alternates/FREE_1200/BJP-symbol" alt="" class="logop"></div>
                </div>
                    <div class="card-footer d-flex align-items-center justify-content-between footer1">
                        <div class="small text-white"> <button class="rem" id="BJP" data-toggle="modal" data-target="#exampleModalCenter" >Vote</button></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="card bg-success text-white mb-4" style="background-image: url('https://qph.cf2.quoracdn.net/main-qimg-f07faec3f1c8c619cc17f3bfbe738836-lq'); opacity: 0.85;">
                    <div class="card-body">congress</div>
                    <div class="card-footer d-flex align-items-center justify-content-between footer1">
                        <div class="small text-white"> <button class="rem" id="congress" data-toggle="modal" data-target="#exampleModalCenter" >Vote</button></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="card bg-danger text-white mb-4" style="background-image: url('https://www.orange.nsw.gov.au/gallery/wp-content/uploads/2021/02/MFLE-image-QgxlNU.tmp_.jpg');">
                    <div class="card-body">RCP</div>
                    <div class="card-footer d-flex align-items-center justify-content-between footer1">
                        <div class="small text-white"> <button class="rem" id="RCP" data-toggle="modal" data-target="#exampleModalCenter" >Vote</button></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="card bg-success text-white mb-4" style="background-image: url('https://resize.indiatv.in/centered/newbucket/1200_675/2022/10/untitled-1-1665201561.jpg');">
                    <div class="card-body">Shivsena</div>
                    <div class="card-footer d-flex align-items-center justify-content-between footer1">
                        <div class="small text-white"> <button class="rem" id="shivsena" data-toggle="modal" data-target="#exampleModalCenter" >Vote</button></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="card bg-success text-white mb-4" style="background-image: url('https://images.unsplash.com/photo-1626785774573-4b799315345d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8Z3JhcGhpYyUyMGRlc2lnbnxlbnwwfHwwfHw%3D&w=1000&q=80');">
                    <div class="card-body">abc</div>
                    <div class="card-footer d-flex align-items-center justify-content-between footer1">
                        <div class="small text-white"> <button class="rem" data-toggle="modal" id="ABC" data-target="#exampleModalCenter" >Vote</button></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="card bg-success text-white mb-4" style="background-image: url('https://thumbs.dreamstime.com/b/quiz-concept-word-text-blackboard-background-79136594.jpg');">
                    <div class="card-body">RJD</div>
                    <div class="card-footer d-flex align-items-center justify-content-between footer1">
                        <div class="small text-white"> <button class="rem" id="RJD" data-toggle="modal" data-target="#exampleModalCenter"  >Vote</button></div>
                    </div>
                    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true"></form>
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="post" action="vote.php">
      <div class="modal-body">
        <h1 class="black" >are you sure you want to vote:</h1>
            <h3 name="party"class="black party"></h3>
            <input type="text" name="party" id="party">
        <H3 class="black">Write "CONFIRM" as it is in below text box</H3>
        <input type="text" id="box">  
    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <submit type="submit" class="btn btn-primary" onclick="check()" >Save changes</submit>
      </div>
    </div>
  </div>
  </form>

</div>
                </div>
            </div>
        </div>
       
        </div>
    <!-- </section> -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="voting_page.js"></script>
    <script>
              
            $("button").click(function() {
                var t = (this.id);
             
                $('.party').text(t);
                $('#party').val(t);
                
            });                     
        </script> 
    
</body>
</html>