<?php 
  $name=$_POST['name'];
  $adhar=$_POST['adhar'];
  $phone=$_POST['phone'];
  $email=$_POST['email'];
  $pass=$_POST['password1'];
  $conn= new mysqli('localhost','root','','registration');
  if($conn->connect_error){
      die('connection failed :'.$conn->connect_error);
  }
  $q="select * from registration where email='email' ";
  $res= mysqli_query($conn,$q);
  $num=mysqli_num_rows($res);
  if($num>0){
    echo'present';
  }
  else{
    
      $stmt=$conn->prepare("insert into registration(name,adhar,phone,email,password)
      values(?,?,?,?,?)");
      $stmt->bind_param("sssss",$name,$adhar,$phone,$email,$pass);
      $stmt->execute();
      $_SESSION['email']=$email;
      $_SESSION['username']=$name;
      header("location:login.php");
      $stmt->close();
      $conn->close();
  }
?>